# Publication Definition of Done

## Chapter

- [ ] Production problem introduced before definition
- [ ] Realistic story included
- [ ] Measurable learning objectives
- [ ] Prerequisites, difficulty, and reading time
- [ ] Big-picture architecture diagram
- [ ] First-principles explanation
- [ ] Internal working
- [ ] Components and responsibilities
- [ ] Data/control flow
- [ ] Performance discussion
- [ ] Scalability discussion
- [ ] Availability and reliability
- [ ] Security
- [ ] Observability
- [ ] Cost and operational complexity
- [ ] Trade-offs and alternatives
- [ ] Production deployment
- [ ] Troubleshooting scenarios
- [ ] Customer architecture discussion
- [ ] Senior-level interview questions
- [ ] Key takeaways
- [ ] Architecture summary
- [ ] Revision sheet
- [ ] Interview notes
- [ ] Lab checklist
- [ ] Cross-references
- [ ] Authoritative further reading
- [ ] No invented facts or output
- [ ] No duplicated explanations
- [ ] Markdown and Mermaid render correctly

## Lab

- [ ] Metadata
- [ ] Objective
- [ ] Background
- [ ] Learning outcomes
- [ ] Architecture
- [ ] Prerequisites
- [ ] Environment
- [ ] Components
- [ ] Deployment
- [ ] Validation
- [ ] Verification
- [ ] Observability
- [ ] Performance measurements
- [ ] Failure injection
- [ ] Troubleshooting
- [ ] Cleanup
- [ ] Summary
- [ ] Challenge exercises
- [ ] Further reading
- [ ] Commands explained
- [ ] Expected output verified or labeled illustrative
- [ ] Failure injection safe and reversible
- [ ] Cleanup restores environment
- [ ] Production relevance included

## Volume

- [ ] Introduction complete
- [ ] All chapters complete
- [ ] All labs complete
- [ ] Category metadata valid
- [ ] Consistent terminology
- [ ] No content duplication
- [ ] All diagrams reviewed
- [ ] All cross-references resolve
- [ ] Branch synchronized with `main`
- [ ] Changed-file scope correct
- [ ] `npm run check` passes
- [ ] GitHub Actions green
- [ ] Technical review passed
- [ ] Editorial review passed
- [ ] Integration review passed
- [ ] PR ready for review
- [ ] Not merged without explicit user approval
