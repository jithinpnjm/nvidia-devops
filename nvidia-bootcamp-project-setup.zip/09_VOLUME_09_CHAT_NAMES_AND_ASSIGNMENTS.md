# Volume 09 — Chat Names and Assignments

Create these chats inside the ChatGPT Project.

## 1. Coordinator

**Chat name**

`V09 Coordinator — Ethernet for AI`

**Initial message**

```text
Act as the coordinator using 01_COORDINATOR_AGENT_PROMPT.md.

Inspect PR #20 and branch book/volume-09-ethernet-for-ai.
Verify the exact filenames and current line counts.
Update 08_VOLUME_09_PRODUCTION_LEDGER.md.
Assign non-overlapping file ownership.
Keep the PR in draft.
Do not merge.
```

## 2. Foundations Writer

**Chat name**

`V09 Writer A — RoCE Foundations`

**Initial message**

```text
Act as a chapter writer using 02_CHAPTER_WRITER_PROMPT.md.

Own only the Volume 09 introduction and Chapters 01–04 after the coordinator confirms exact filenames.

Focus on:
- why AI Ethernet differs;
- RoCE architecture and packet paths;
- PFC and pause behavior;
- ECN and DCQCN.

Do not modify Chapters 05–12 or labs.
Commit in small logical batches and provide the required handoff.
```

## 3. Fabric Writer

**Chat name**

`V09 Writer B — Spectrum, ConnectX, BlueField, DOCA`

**Initial message**

```text
Act as a chapter writer using 02_CHAPTER_WRITER_PROMPT.md.

Own only Chapters 05–08 after the coordinator confirms filenames.

Focus on:
- Spectrum switch architecture;
- ConnectX Ethernet and RoCE behavior;
- BlueField DPU architecture;
- DOCA and infrastructure services.

Avoid repeating RoCE, PFC, ECN, and DCQCN fundamentals owned by Writer A.
```

## 4. Operations Writer

**Chat name**

`V09 Writer C — Topology, Observability, Production`

**Initial message**

```text
Act as a chapter writer using 02_CHAPTER_WRITER_PROMPT.md.

Own only Chapters 09–12 after the coordinator confirms filenames.

Focus on:
- topologies and rail design;
- observability and performance validation;
- production design and troubleshooting;
- volume synthesis.

Do not re-teach protocol fundamentals.
```

## 5. Lab Engineer

**Chat name**

`V09 Lab Engineer — AI Ethernet`

**Initial message**

```text
Act as the lab engineer using 03_LAB_WRITER_PROMPT.md.

Own all four Volume 09 lab files after the coordinator confirms filenames.

Every lab must follow the complete 18-section standard.
Include safe failure injection, expected evidence, observability, cleanup, and production relevance.
Do not modify chapters.
```

## 6. Technical Reviewer

**Chat name**

`V09 Technical Review — Ethernet and RoCE`

**Initial message**

```text
Act as the technical reviewer using 04_TECHNICAL_REVIEWER_PROMPT.md.

Review all Volume 09 changed files after writer handoffs.
Verify claims using primary sources.
Focus on RoCE, PFC, ECN, DCQCN, Spectrum, ConnectX, BlueField, DOCA, topology, congestion, and operational failure modes.
Return actionable findings only.
```

## 7. Editorial Reviewer

**Chat name**

`V09 Editorial Review — Book Quality`

**Initial message**

```text
Act as the editorial reviewer using 05_EDITORIAL_REVIEWER_PROMPT.md.

Review the complete Volume 09 as one book unit.
Check voice, learning sequence, repetition, diagram density, customer perspective, troubleshooting depth, and interview quality.
Reject outline-like or template-like writing.
```

## 8. Integration Reviewer

**Chat name**

`V09 Integration — Docusaurus and CI`

**Initial message**

```text
Act as the integration reviewer using 06_INTEGRATION_REVIEWER_PROMPT.md.

Check the complete book/volume-09-ethernet-for-ai branch and PR #20.
Verify changed-file scope, routes, links, Mermaid, front matter, npm run check, and GitHub Actions.
Keep the PR draft until all checks pass.
Do not merge.
```
