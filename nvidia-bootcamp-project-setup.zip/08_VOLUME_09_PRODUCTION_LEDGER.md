# Volume 09 — Ethernet for AI Production Ledger

Repository: `jithinpnjm/nvidia-devops`  
Integration branch: `book/volume-09-ethernet-for-ai`  
Pull request: `#20`  
Current state: Draft / Quality Rework Required

## Workstreams

| Workstream | Suggested owner | Files |
|---|---|---|
| Volume framing | Coordinator or Writer A | `index.md` |
| Foundations | Writer A | Chapters 01–04 |
| Fabric architecture | Writer B | Chapters 05–08 |
| Operations and design | Writer C | Chapters 09–12 |
| Labs | Lab Engineer | Labs 01–04 |
| Technical review | Technical Reviewer | All files |
| Editorial review | Editorial Reviewer | All files |
| Integration and CI | Integration Reviewer | Full branch |

## File Ledger

| File | Owner | Draft rewrite | Technical review | Editorial review | Integration | CI |
|---|---|---:|---:|---:|---:|---:|
| `index.md` | Coordinator | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-01-why-ethernet-for-ai-is-different.md` | Writer A | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-02-roce-architecture-and-packet-paths.md` | Writer A | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-03-lossless-ethernet-pfc-and-pause-behavior.md` | Writer A | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-04-ecn-and-dcqcn-congestion-control.md` | Writer A | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-05-spectrum-switch-architecture.md` | Writer B | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-06-connectx-ethernet-and-roce-adapters.md` | Writer B | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-07-bluefield-dpu-architecture.md` | Writer B | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-08-doca-and-infrastructure-services.md` | Writer B | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-09-ai-ethernet-topologies-and-rail-design.md` | Writer C | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-10-observability-and-performance-validation.md` | Writer C | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-11-production-design-and-troubleshooting.md` | Writer C | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `chapter-12-volume-09-summary.md` | Writer C | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `labs/lab-01-inventory-an-ai-ethernet-fabric.md` | Lab Engineer | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `labs/lab-02-validate-pfc-ecn-and-roce.md` | Lab Engineer | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `labs/lab-03-benchmark-roce-bandwidth-and-latency.md` | Lab Engineer | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| `labs/lab-04-troubleshoot-an-ai-ethernet-path.md` | Lab Engineer | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |

> Confirm exact existing filenames on the branch before assigning work. Update this ledger if the repository uses different names.

## Shared Technical Boundaries

To prevent duplication:

- Chapter 01 owns the workload problem and why Ethernet needs special treatment.
- Chapter 02 owns RoCE packet and memory paths.
- Chapter 03 owns PFC and pause propagation.
- Chapter 04 owns ECN and DCQCN behavior.
- Chapter 05 owns Spectrum switch architecture.
- Chapter 06 owns ConnectX Ethernet/RoCE adapter behavior.
- Chapter 07 owns BlueField hardware and control/data-plane separation.
- Chapter 08 owns DOCA software and infrastructure services.
- Chapter 09 owns topology, rails, oversubscription, and failure domains.
- Chapter 10 owns observability, counters, baselines, and validation.
- Chapter 11 owns production scenarios and integrated troubleshooting.
- Chapter 12 synthesizes without re-teaching all details.

## Acceptance Gates

- [ ] Every file rewritten to publication quality
- [ ] Every chapter contains required learning structure
- [ ] Every lab contains all 18 required sections
- [ ] No duplicated explanations
- [ ] All diagrams reviewed
- [ ] All technical claims reviewed
- [ ] All links resolve
- [ ] Branch synchronized with `main`
- [ ] `npm run check` passes
- [ ] GitHub Actions green
- [ ] PR marked ready by coordinator
