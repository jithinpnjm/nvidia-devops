# NVIDIA Zero to Hero Bootcamp — Project Instructions

You are contributing to the NVIDIA Zero to Hero Bootcamp repository:

`jithinpnjm/nvidia-devops`

## Mandatory Reading Order

Before writing or reviewing content, read:

1. `00_PROJECT_CHARTER.md`
2. `01_CONTENT_SPECIFICATION.md`
3. `02_ROADMAP.md`
4. `03_CONTRIBUTING_AI.md`
5. `04_EDITORIAL_GUIDE.md`
6. `05_ARCHITECTURE_PRINCIPLES.md`
7. `06_LAB_STANDARD.md`
8. `07_DIAGRAM_STANDARD.md`
9. The target volume introduction
10. The complete target chapter or lab being modified

Never skip this sequence.

## Mission

Build the most comprehensive open-source NVIDIA AI Infrastructure learning platform available.

This is not:

- an interview dump;
- a certification cram guide;
- a loose note collection;
- a vendor documentation rewrite;
- generic AI-generated prose.

The target reader is an experienced DevOps, SRE, Platform, Cloud, Infrastructure, or MLOps engineer who may have no prior NVIDIA knowledge.

## Teaching Order

Every technology must be taught in this sequence:

WHY  
↓  
WHAT  
↓  
HOW  
↓  
WHEN  
↓  
TRADE-OFFS  
↓  
PRODUCTION  
↓  
TROUBLESHOOTING

Never reverse this order.

## Publication-Quality Requirements

Each chapter must include, where appropriate:

- realistic production problem and story;
- measurable learning objectives;
- prerequisites, difficulty, and estimated reading time;
- big-picture architecture diagram;
- first-principles explanation;
- internal working and data flow;
- architecture trade-offs;
- scalability, availability, performance, security, reliability, observability, cost, and operational complexity;
- production deployment patterns;
- troubleshooting scenarios with symptoms, diagnosis, evidence, root cause, resolution, verification, and prevention;
- customer architecture discussion;
- senior-level interview questions;
- key takeaways;
- architecture summary;
- quick revision sheet;
- interview notes;
- lab checklist;
- cross-references;
- authoritative further reading.

Chapters must not be outline-sized, padded, repetitive, or template-like.

## Lab Requirements

Every lab must follow all sections in `06_LAB_STANDARD.md`:

1. Objective
2. Background
3. Learning Outcomes
4. Architecture
5. Prerequisites
6. Environment
7. Components
8. Deployment Steps
9. Validation
10. Verification
11. Observability
12. Performance Measurements
13. Failure Injection
14. Troubleshooting
15. Cleanup
16. Summary
17. Challenge Exercises
18. Further Reading

Every command must include purpose, command, expected output, explanation, and common failure interpretation.

Never invent command output. Use representative output only when clearly labeled as illustrative.

## Technical Accuracy

Never invent:

- performance numbers;
- product specifications;
- limits;
- compatibility claims;
- benchmark results;
- release behavior;
- command output;
- feature support;
- architecture constraints.

Use primary sources for technical verification:

- NVIDIA documentation;
- official product guides;
- official specifications;
- standards;
- academic papers;
- upstream project documentation.

Prefer concepts over fragile version-specific claims. When versions materially matter, state them explicitly.

## Visual Standard

Use architecture-first presentation.

Preferred order:

Architecture diagram  
↓  
Flow diagram  
↓  
Comparison table  
↓  
Configuration  
↓  
Commands  
↓  
Expected output  
↓  
Explanation

Use original Mermaid diagrams wherever practical.

Keep Mermaid diagrams readable:

- maximum approximately 12–15 nodes;
- one clear engineering question per diagram;
- no decorative complexity;
- label important arrows;
- avoid crossed arrows.

## Editorial Style

Write as an NVIDIA Principal Solutions Architect teaching another experienced engineer.

Use:

- American English;
- direct sentences;
- short paragraphs;
- consistent terminology;
- engineering language;
- production examples;
- explicit trade-offs.

Avoid:

- marketing language;
- Wikipedia-style definitions;
- bullet dumps;
- generic conclusions;
- fake quotations;
- repeated explanations already covered elsewhere.

## Git and Repository Rules

- One volume per branch.
- One worker owns one file at a time.
- Writers never merge into `main`.
- Preserve existing filenames and routes unless the coordinator approves a migration.
- Use lowercase and hyphenated filenames.
- Do not create cross-links to unpublished pages unless using the repository-approved mechanism.
- Every branch must pass `npm run check`.
- GitHub Actions must be green before a PR is marked ready.
- Never merge unless the user explicitly requests it.

## Definition of Done

A file is complete only when it passes:

1. Structural review
2. Technical review
3. Editorial review
4. Duplication review
5. Route and link review
6. Mermaid review
7. Lab reproducibility review, when applicable
8. CI and Docusaurus build validation

A volume is complete only when:

- its introduction is publication-ready;
- all chapters are publication-ready;
- all labs are publication-ready;
- category metadata is correct;
- all cross-references resolve;
- all CI checks pass;
- the coordinator marks the PR ready for review.
