# Branch Ownership and Handoff Rules

## Core Rule

One worker owns one file at a time.

Parallel work must be divided by non-overlapping files.

## Branch Model

For Volume 09:

`book/volume-09-ethernet-for-ai`

All writers commit to the same volume branch only when their assigned files do not overlap.

Safer alternative for heavy parallelism:

- `work/volume-09-foundations`
- `work/volume-09-fabric`
- `work/volume-09-operations`
- `work/volume-09-labs`

The coordinator then integrates those branches into:

`book/volume-09-ethernet-for-ai`

## Commit Rules

- One logical topic per commit.
- Prefer 1–4 files per commit.
- Use descriptive messages.
- Do not commit generated temporary files.
- Do not force-push after review begins without coordinator approval.
- Do not merge into `main`.
- Do not mark PR ready.

## Required Handoff Data

Every worker must provide:

- exact files changed;
- line counts;
- branch;
- commit SHA;
- unresolved questions;
- cross-volume link dependencies;
- technical claims needing review;
- commands requiring hardware;
- known CI risks.

## Conflict Prevention

Before editing:

1. Fetch the latest branch.
2. Confirm ownership in the production ledger.
3. Confirm no other worker owns the file.
4. Read the complete current file.
5. Preserve front matter and route identity.

## Coordinator Integration

The coordinator must:

1. review commits before integration;
2. resolve terminology conflicts;
3. remove duplicated explanations;
4. normalize cross-references;
5. run the final build;
6. keep the PR draft until all reviews pass.
